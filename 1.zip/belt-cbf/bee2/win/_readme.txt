To suppress the LNK4099 warning copy libcmt.pdb and libcmtd.pdb files 
from VStudio/VC/lib[/amd64] to distrib/{{Release|Debug}{32|64}}
